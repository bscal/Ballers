internal enum MatchState {
    HasSymbol = 1,
    HasMatch = 2,
    HasSymbolAndMatch = 3
}
